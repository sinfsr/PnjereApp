package ir.pnjere.browser;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONArray;
import org.json.JSONObject;

public class NotifyPollWorker extends Worker {

    public static final String CHANNEL_ID = "pnjere_notifications";

    public NotifyPollWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            Context ctx = getApplicationContext();
            String deviceId = DeviceId.get(ctx);

            JSONObject payload = new JSONObject();
            payload.put("action", "poll_notifications");
            payload.put("device_id", deviceId);

            JSONObject resp = ApiClient.post(ApiClient.NOTIFY_URL, payload);
            if (resp == null || !resp.optBoolean("ok", false)) {
                return Result.retry();
            }

            JSONArray list = resp.optJSONArray("notifications");
            if (list == null || list.length() == 0) {
                return Result.success();
            }

            ensureChannel(ctx);
            for (int i = 0; i < list.length(); i++) {
                JSONObject n = list.getJSONObject(i);
                showNotification(ctx, n.optInt("id"), n.optString("title"), n.optString("body"), n.optString("url", null));
            }
            return Result.success();
        } catch (Exception e) {
            return Result.retry();
        }
    }

    private void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = ctx.getSystemService(NotificationManager.class);
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "اطلاعیه‌های پنجره", NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(channel);
        }
    }

    private void showNotification(Context ctx, int notifId, String title, String body, String url) {
        Intent intent = new Intent(ctx, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        if (url != null && !url.isEmpty()) {
            intent.putExtra(MainActivity.EXTRA_OPEN_URL, url);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pendingIntent = PendingIntent.getActivity(ctx, notifId, intent, flags);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent);

        try {
            NotificationManagerCompat.from(ctx).notify(notifId, builder.build());
        } catch (SecurityException ignored) {
            // مجوز POST_NOTIFICATIONS داده نشده؛ بی‌خیال نمایش نوتیف می‌شیم
        }
    }
}
