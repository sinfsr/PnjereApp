package ir.pnjere.browser;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import org.json.JSONObject;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    private static final String SITE_URL = "https://pnjere.ir";
    // آدرس صفحه‌ی فورس‌آپدیت رو خودِ سایت میزبانیش می‌کنه؛ یعنی سینا هر وقت خواست
    // متن/طراحی/لینک دکمه رو عوض کنه، فقط همین فایل رو رو سرور آپلود می‌کنه،
    // نیازی به ساخت نسخه‌ی جدید اپ نیست
    private static final String FORCE_UPDATE_PATH = "/force-update.html";
    private static final int FILE_CHOOSER_REQUEST_CODE = 200;
    private static final int NOTIF_PERMISSION_REQUEST_CODE = 300;
    public static final String EXTRA_OPEN_URL = "extra_open_url";

    private WebView webView;
    private FrameLayout fullscreenContainer;
    private ValueCallback<Uri[]> filePathCallback;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private final ExecutorService bgExecutor = Executors.newSingleThreadExecutor();
    private int appVersionCode = 0;
    private String appVersionName = "0";
    private volatile String lastKnownUid = null;
    // وقتی true باشه یعنی اپ فورس‌آپدیت شده و رو صفحه‌ی force-update.html قفله؛
    // دیگه نه دکمه‌ی برگشت کار می‌کنه نه لینک‌های داخل سایت
    private volatile boolean forceUpdateActive = false;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // حذف نوار وضعیت و نوار پایین رنگی: محتوای وب‌ویو تا لبه صفحه کشیده می‌شه
        // و پس‌زمینه‌اش دقیقاً همون رنگیه که خود سایت داره (نه رنگ ثابت صورتی/سفید)
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);
        WindowInsetsControllerCompat insetsController =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (insetsController != null) {
            // آیکون‌های نوار وضعیت روشن (چون پس‌زمینه بالای سایت پررنگه)
            insetsController.setAppearanceLightStatusBars(false);
            // آیکون‌های نوار پایین تیره (چون پس‌زمینه پایین سایت سفیده)
            insetsController.setAppearanceLightNavigationBars(true);
        }
        if (Build.VERSION.SDK_INT >= 29) {
            // اندروید به‌صورت خودکار یه لایه‌ی نیمه‌شفاف پشت نوار پایین (خط ژست) می‌کشه
            // که همون خط سفید رو ایجاد می‌کرد؛ اینجا غیرفعالش می‌کنیم
            getWindow().setNavigationBarContrastEnforced(false);
            getWindow().setStatusBarContrastEnforced(false);
        }

        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        fullscreenContainer = findViewById(R.id.fullscreenContainer);

        int versionCode = 0;
        String versionName = "0";
        try {
            PackageInfo pInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            versionName = pInfo.versionName;
            versionCode = Build.VERSION.SDK_INT >= 28 ? (int) pInfo.getLongVersionCode() : pInfo.versionCode;
        } catch (Exception ignored) {
        }
        appVersionCode = versionCode;
        appVersionName = versionName;

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        // کاهش زوم پیش‌فرض؛ عدد بین حالت اولیه (۱۰۰، بزرگ) و تست قبلی (۹۰، کوچیک) قرار گرفت
        settings.setTextZoom(99);
        // این بخش به سایت اجازه می‌ده بفهمه کاربر از اپ اومده و با چه نسخه‌ای؛
        // تو PHP کافیه دنبال «PnjereApp/» تو HTTP_USER_AGENT بگردی
        settings.setUserAgentString(settings.getUserAgentString() + " PnjereApp/" + versionName + " (build " + versionCode + ")");

        // مجوز نمایش نوتیفیکیشن (اندروید ۱۳ به بعد صریحاً باید درخواست بشه)
        if (Build.VERSION.SDK_INT >= 33) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIF_PERMISSION_REQUEST_CODE);
            }
        }

        // پل جاوااسکریپت: سایت با AndroidBridge.setUid(uid) به اپ می‌گه این کاربر کیه
        // تا بشه براش نوتیف «کاربر خاص» یا «نیچ موردعلاقه‌ش» فرستاد
        webView.addJavascriptInterface(new AndroidBridge(this::onSiteUidReceived), "AndroidBridge");

        // چک کردن نسخه‌ی اپ (فورس آپدیت) + ثبت دستگاه برای نوتیفیکیشن — هر دو تو پس‌زمینه
        checkAppVersion(versionCode);
        registerDevice(versionCode, versionName, null);
        schedulePeriodicNotifyPoll();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith(SITE_URL) || url.startsWith("https://www.pnjere.ir")) {
                    // وقتی فورس‌آپدیت فعاله فقط اجازه‌ی خودِ صفحه‌ی force-update.html رو می‌دیم؛
                    // بقیه‌ی صفحات سایت لود نمی‌شن تا کاربر نتونه دورش بزنه
                    if (forceUpdateActive && !url.contains(FORCE_UPDATE_PATH)) {
                        return true;
                    }
                    return false;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                }
                return true;
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                // pnjere.ir از SSL معتبر استفاده می‌کنه؛ در صورت خطای واقعی، درخواست کنسل می‌شه
                handler.cancel();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST_CODE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }

            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customViewCallback = callback;
                fullscreenContainer.addView(view, new ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                fullscreenContainer.setVisibility(View.VISIBLE);
                webView.setVisibility(View.GONE);
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) return;
                fullscreenContainer.setVisibility(View.GONE);
                fullscreenContainer.removeView(customView);
                webView.setVisibility(View.VISIBLE);
                customView = null;
                if (customViewCallback != null) {
                    customViewCallback.onCustomViewHidden();
                    customViewCallback = null;
                }
            }
        });

        webView.loadUrl(resolveStartUrl(getIntent()));
    }

    private String resolveStartUrl(Intent intent) {
        if (intent != null) {
            String url = intent.getStringExtra(EXTRA_OPEN_URL);
            if (url != null && !url.isEmpty()) return url;
        }
        return SITE_URL;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String url = intent.getStringExtra(EXTRA_OPEN_URL);
        if (url != null && !url.isEmpty() && webView != null) {
            webView.loadUrl(url);
        }
    }

    /** چک می‌کنه نسخه‌ی نصب‌شده هنوز مجازه یا نه؛ اگه نه، به صفحه‌ی فورس‌آپدیتِ خودِ سایت هدایت می‌کنه. */
    private void checkAppVersion(int versionCode) {
        bgExecutor.execute(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("action", "check_app_version");
                payload.put("app_version_code", versionCode);
                JSONObject resp = ApiClient.post(ApiClient.NOTIFY_URL, payload);
                if (resp != null && resp.optBoolean("ok", false) && resp.optBoolean("force_update", false)) {
                    String message = resp.optString("update_message", "برای ادامه باید اپ رو بروزرسانی کنی.");
                    String updateUrl = resp.optString("update_url", "");
                    runOnUiThread(() -> redirectToForceUpdate(message, updateUrl));
                }
            } catch (Exception ignored) {
                // اگه سرور در دسترس نبود، اپ رو نمی‌بندیم؛ فقط چک بی‌خیال می‌شه
            }
        });
    }

    /**
     * به‌جای نمایش یه صفحه‌ی ثابتِ داخل کد اپ، وب‌ویو رو می‌بریم رو یه صفحه‌ی واقعی از سایت
     * (force-update.html). پیام و لینک بروزرسانی رو به‌صورت querystring پاس می‌دیم تا اون
     * صفحه فوراً و بدون نیاز به درخواست اضافه نمایش داده بشه؛ ولی چون خودِ صفحه هم یه فایل
     * روی سایته، سینا هر وقت خواست می‌تونه طراحی/متن/رفتارش رو مستقل از اپ عوض کنه.
     */
    private void redirectToForceUpdate(String message, String updateUrl) {
        forceUpdateActive = true;
        String target = SITE_URL + FORCE_UPDATE_PATH
                + "?msg=" + Uri.encode(message)
                + "&update_url=" + Uri.encode(updateUrl)
                + "&cur=" + Uri.encode(appVersionName);
        webView.loadUrl(target);
    }

    /** دستگاه رو تو سرور ثبت/آپدیت می‌کنه تا بتونه نوتیفیکیشن هدفمند بگیره. */
    private void registerDevice(int versionCode, String versionName, String uid) {
        bgExecutor.execute(() -> {
            try {
                JSONObject payload = new JSONObject();
                payload.put("action", "register_device");
                payload.put("device_id", DeviceId.get(getApplicationContext()));
                payload.put("app_version_code", versionCode);
                payload.put("app_version_name", versionName);
                payload.put("os_version", "Android " + Build.VERSION.RELEASE);
                payload.put("model", Build.MANUFACTURER + " " + Build.MODEL);
                if (uid != null) payload.put("uid", uid);
                ApiClient.post(ApiClient.NOTIFY_URL, payload);
            } catch (Exception ignored) {
            }
        });
    }

    /** وقتی سایت (از طریق JS) uid کاربر فعلی رو اعلام می‌کنه، دستگاه رو با اون uid آپدیت می‌کنیم. */
    private void onSiteUidReceived(String uid) {
        if (uid.equals(lastKnownUid)) return; // قبلاً همینو فرستادیم، دوباره نزن
        lastKnownUid = uid;
        registerDevice(appVersionCode, appVersionName, uid);
    }

    /** هر ۱۵ دقیقه (کمینه‌ی مجاز اندروید) یه بار سرور رو برای نوتیفیکیشن جدید چک می‌کنه. */
    private void schedulePeriodicNotifyPoll() {
        WorkManager wm = WorkManager.getInstance(getApplicationContext());

        // یه چک فوری همین الان (تا نوتیف‌های در انتظار سریع‌تر از ۱۵ دقیقه برسن)
        wm.enqueue(new OneTimeWorkRequest.Builder(NotifyPollWorker.class).build());

        // + چک دوره‌ای برای وقتی اپ تو پس‌زمینه‌ست
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                NotifyPollWorker.class, 15, TimeUnit.MINUTES).build();
        wm.enqueueUniquePeriodicWork("pnjere_notify_poll", ExistingPeriodicWorkPolicy.KEEP, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_CHOOSER_REQUEST_CODE) {
            if (filePathCallback == null) {
                super.onActivityResult(requestCode, resultCode, data);
                return;
            }
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                String dataString = data.getDataString();
                if (dataString != null) {
                    results = new Uri[]{Uri.parse(dataString)};
                } else if (data.getClipData() != null) {
                    int count = data.getClipData().getItemCount();
                    results = new Uri[count];
                    for (int i = 0; i < count; i++) {
                        results[i] = data.getClipData().getItemAt(i).getUri();
                    }
                }
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    protected void onDestroy() {
        bgExecutor.shutdown();
        super.onDestroy();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (forceUpdateActive) {
                // تا وقتی فورس‌آپدیته، برگشت نباید کاربر رو از این صفحه ببره بیرون
                return true;
            }
            if (webView.canGoBack()) {
                webView.goBack();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
