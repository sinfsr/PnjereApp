package ir.pnjere.browser;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.UUID;

/** یه شناسه‌ی یکتا و پایدار برای این نصبِ اپ می‌سازه و تو SharedPreferences نگه می‌داره. */
public class DeviceId {

    private static final String PREFS = "pnjere_prefs";
    private static final String KEY_DEVICE_ID = "device_id";

    public static String get(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String id = prefs.getString(KEY_DEVICE_ID, null);
        if (id == null) {
            id = UUID.randomUUID().toString();
            prefs.edit().putString(KEY_DEVICE_ID, id).apply();
        }
        return id;
    }
}
