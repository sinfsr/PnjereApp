package ir.pnjere.browser;

import android.webkit.JavascriptInterface;

/**
 * پل بین جاوااسکریپت سایت و اپ. سایت وقتی uid کاربر رو می‌دونه
 * (حتی کاربر مهمون/ناشناس) صداش می‌زنه: AndroidBridge.setUid(uid)
 * تا این دستگاه تو سرور به همون uid وصل بشه و بشه براش نوتیف نیچ/کاربر خاص فرستاد.
 */
public class AndroidBridge {

    public interface UidListener {
        void onUidReceived(String uid);
    }

    private final UidListener listener;

    public AndroidBridge(UidListener listener) {
        this.listener = listener;
    }

    @JavascriptInterface
    public void setUid(String uid) {
        if (uid != null && !uid.isEmpty() && listener != null) {
            listener.onUidReceived(uid);
        }
    }
}
