package ir.pnjere.browser;

import android.util.Log;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * کلاینت خیلی ساده برای صدا زدن notify.php (ثبت دستگاه، چک نسخه، گرفتن نوتیف‌ها).
 * همیشه باید از یه ترد پس‌زمینه صدا زده بشه (نه UI thread).
 */
public class ApiClient {

    private static final String TAG = "PnjereApi";
    public static final String NOTIFY_URL = "https://pnjere.ir/notify.php";

    /** یه POST با بدنه‌ی JSON می‌زنه و JSONObject جواب رو برمی‌گردونه؛ اگه خطا بود null. */
    public static JSONObject post(String url, JSONObject payload) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                os.write(payload.toString().getBytes(StandardCharsets.UTF_8));
            }

            int code = conn.getResponseCode();
            java.io.InputStream is = (code >= 200 && code < 300) ? conn.getInputStream() : conn.getErrorStream();
            if (is == null) return null;

            String text;
            try (Scanner scanner = new Scanner(is, "UTF-8")) {
                scanner.useDelimiter("\\A");
                text = scanner.hasNext() ? scanner.next() : "";
            }
            return new JSONObject(text);
        } catch (Exception e) {
            Log.w(TAG, "request failed: " + e.getMessage());
            return null;
        } finally {
            if (conn != null) conn.disconnect();
        }
    }
}
